import React from "react";

const Contact = () => {
  return (
    <div>
      <h1>This is the contact Page</h1>
    </div>
  );
};

export default Contact;
