import React from "react";

const BuyNow = () => {
  return (
    <div>
      <h1>This is the buy now page</h1>
    </div>
  );
};

export default BuyNow;
