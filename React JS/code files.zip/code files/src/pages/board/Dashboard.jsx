import React from "react";

const Dashboard = () => {
  return (
    <div>
      <img src="./vite.svg" alt="" />
      <h1>This is the dashboard</h1>
    </div>
  );
};

export default Dashboard;
