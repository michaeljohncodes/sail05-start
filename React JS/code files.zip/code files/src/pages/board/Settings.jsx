import React from "react";

const Settings = () => {
  return (
    <div>
      <h1>This is the settings</h1>
      <img src="./vite.svg" alt="" />
    </div>
  );
};

export default Settings;
