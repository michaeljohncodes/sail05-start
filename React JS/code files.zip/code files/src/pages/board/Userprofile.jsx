import React from "react";

const Userprofile = () => {
  return (
    <div>
      <h1>This is the user profile page</h1>
    </div>
  );
};

export default Userprofile;
